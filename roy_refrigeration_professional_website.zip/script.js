function toggleMenu(){const nav=document.getElementById("nav");if(nav)nav.classList.toggle("open")}
document.querySelectorAll("#year").forEach(el=>el.textContent=new Date().getFullYear());
const dateField=document.getElementById("date");if(dateField)dateField.min=new Date().toLocaleDateString("en-CA");
const serviceSelect=document.getElementById("service");
const params=new URLSearchParams(window.location.search);
if(serviceSelect&&params.get("service")){const wanted=params.get("service");for(const opt of serviceSelect.options){if(opt.text.toLowerCase()===wanted.toLowerCase()||opt.value.toLowerCase()===wanted.toLowerCase()){serviceSelect.value=opt.value;break;}}}
function sendBooking(event){event.preventDefault();
const name=document.getElementById("customer").value.trim();
const phone=document.getElementById("phone").value.trim();
const service=document.getElementById("service").value;
const address=document.getElementById("address").value.trim();
const date=document.getElementById("date").value;
const problem=document.getElementById("problem").value.trim();
const message="Roy Refrigeration — Service Booking Request\n\nName: "+name+"\nCustomer phone: "+phone+"\nService: "+service+"\nAddress: "+address+"\nPreferred date: "+date+"\nProblem: "+(problem||"Not specified")+"\n\nPlease confirm availability and estimated cost.";
window.location.href="https://wa.me/918016771430?text="+encodeURIComponent(message);
}
